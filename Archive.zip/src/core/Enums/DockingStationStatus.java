package Enums;

public enum DockingStationStatus{
	ONLINE,
	OFFLINE
}


