package Enums;

public enum BicycleType {
    ELECTRIC,
    MECHANICAL
}
