package Enums;

public enum ParkingSlotStatus{
	Occupied,
	Free,
	OutOfOrder,

}