package Enums;

public enum DockingStationType{
	STANDARD,
	PLUS
}

