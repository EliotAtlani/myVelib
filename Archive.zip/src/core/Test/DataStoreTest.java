package Test;

public class DataStoreTest {

    @Test
    @DisplayName("Test of the type of bicycles");
    
    
}
