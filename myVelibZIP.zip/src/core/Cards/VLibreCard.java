package core.Cards;

/**
 * Create VLibreCard for a user
 */
public class VLibreCard extends RegistrationCard{
	
	public VLibreCard(){
		super(true,0,1,1,2);
		
	}

	
	
	/** 
	 * @return String
	 */
	@Override
    public String toString() {
        return "VLIBRE cards";
    }

}
