package core.Enums;

public enum DockingStationType{
	STANDARD,
	PLUS
}

