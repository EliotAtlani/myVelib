package core.Enums;

public enum ParkingSlotStatus{
	Occupied,
	Free,
	OutOfOrder,

}