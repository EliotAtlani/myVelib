package core.Enums;

public enum BicycleType {
    ELECTRIC,
    MECHANICAL
}
