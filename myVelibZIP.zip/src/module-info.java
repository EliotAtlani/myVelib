/**
 * 
 */
/**
 * @author eliotatlani
 *
 */
module myVelib {
	requires junit;
	requires org.junit.jupiter.api;
	
}